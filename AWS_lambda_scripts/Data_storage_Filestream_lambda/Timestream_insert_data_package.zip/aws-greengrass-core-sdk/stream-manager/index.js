/*
 * Copyright (c) 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 */

/**
 * @namespace aws-greengrass-core-sdk.StreamManager
 */

module.exports = require('./client');
